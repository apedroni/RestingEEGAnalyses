v2.3 versus v2.2
- added the function adjustcylinder2.m
