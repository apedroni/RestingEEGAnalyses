##Microstate EEGlab toolbox

Extention for EEGlab, enabling microstate analysis in Matlab. Includes full GUI support and ability to run from command window. At the moment v1.0 is continuously updated, though it should be stable.

A guide to the toolbox is coming soon.

Please cite this toolbox as:

Poulsen, A. T., Pedroni, A., Langer, N., &  Hansen, L. K. (unpublished manuscript).
Microstate EEGlab toolbox: An introductionary guide.
